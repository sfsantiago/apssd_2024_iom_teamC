package org.scrum.psd.battleship.controller.dto;

public enum Color {
    CADET_BLUE, CHARTREUSE, ORANGE, RED, YELLOW;
}
